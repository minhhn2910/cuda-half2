./lavaMD.exe -boxes1d 2
